import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class BoxLife extends PApplet {

/*********************************************************
 *  Name: Somar Ani                                       *
 *  Course: ICS 3U 02  Pd. 8                              *
 *  Summative                                             *
 *  Due Date: May 27, 2015                                *
 *********************************************************/

//Creates all variable

State currentState;
SplashScreen splash;
Menu menu;
DifficultySelector diff;
Tutorial tutorial;
LevelOne lvl1;
LevelTwo lvl2;
LevelThree lvl3;
LevelFour lvl4;
LevelFive lvl5;
LevelSix lvl6;
LevelSeven lvl7; 
LevelEight lvl8;
LevelNine lvl9;
LevelTenA lvl10a;
LevelTenB lvl10b;

GameOver gameOver;
WinScreen winScreen;

int difficulty;
int lives;

boolean isCheater = false;

float remainingTime;

int finalLevel = 1;
float startingTime;
float finalTime;

boolean[] keys = new boolean[10];
boolean[] keysReleased = new boolean[10];

//keyboard constants 
final int W = 0; 
final int A = 1; 
final int S = 2; 
final int D = 3; 
final int ENTR = 4; 
final int SPACE = 5; 

//Setup method runs once at beggining of program to initialize everything ///////////////////////////////////////////////////////////////////////
public void setup() {
  menu = new Menu();
  splash = new SplashScreen();
  diff = new DifficultySelector();

  tutorial = new Tutorial();
  lvl1 = new LevelOne();
  lvl2 = new LevelTwo();
  lvl3 = new LevelThree();
  lvl4 = new LevelFour();
  lvl5 = new LevelFive();
  lvl6 = new LevelSix();
  lvl7 = new LevelSeven();
  lvl8 = new LevelEight();
  lvl9 = new LevelNine();
  lvl10a = new LevelTenA();
  lvl10b = new LevelTenB();

  gameOver = new GameOver();
  winScreen = new WinScreen();

  currentState = splash;
  currentState.initialize();

   

  noStroke();

  for (int i = 0; i < keysReleased.length; i++) {
    keysReleased[i] = true;
  }
}

//Main draw loop. Calls the draw loop of current state ///////////////////////////////////////////////////////////////////////////////////
public void draw() {
  currentState.draw();
}

//Method to switch states. Updates current state and runs initialize method of the new state. s: state to switch to/////////////////////////////////
public void setState(State s) {
  currentState = s; 
  currentState.initialize();
}

//Checks if a key has been pressed and sets its value as true in the key array //////////////////////////////////////////////////////////
public void keyPressed() {

  if (key == 'a' || key == 'A')  keys[A] = true;
  if (key == 'w' || key == 'W')  keys[W] = true;
  if (key == 'd' || key == 'D')  keys[D] = true;
  if (key == 's' || key == 'S')  keys[S] = true;
  if (keyCode == ENTER) keys[ENTR] = true;

  //Keys Used to switch levels
  if (key == '1') {
    setState(lvl1);
    isCheater = true;
  } else if (key == '2') {
    setState(lvl2);
    isCheater = true;
  } else if (key == '3') {
    setState(lvl3);
    isCheater = true;
  } else if (key == '4') {
    setState(lvl4);
    isCheater = true;
  } else if (key == '5') {
    setState(lvl5);
    isCheater = true;
  } else if (key == '6') {
    setState(lvl6);
    isCheater = true;
  } else if (key == '7') {
    setState(lvl7);
    isCheater = true;
  } else if (key == '8') {
    setState(lvl8);
    isCheater = true;
  } else if (key == '9') {
    setState(lvl9);
    isCheater = true;
  } else if (key == '0') {
    setState(lvl10a);
    isCheater = true;
  }
}


//Checks if a key has been released and sets its value as false in the key array //////////////////////////////////////////////////////////
public void keyReleased() {

  if (key == 'a' || key == 'A')  keys[A] = false;
  if (key == 'w' || key == 'W')  keys[W] = false;
  if (key == 'd' || key == 'D')  keys[D] = false;
  if (key == 's' || key == 'S')  keys[S] = false;
  if (keyCode == ENTER) keys[ENTR] = false;

  if (key == 'w' || key == 'W')  keysReleased[W] = true;
  if (key == 's' || key == 'S')  keysReleased[S] = true;
}

//Calls the setup method to reset all values //////////////////////////////////////////////////////////////////////////////////////////////
public void reset() {
  setup();
}
// Class for animating a sequence of GIFs
// Originally taken from processing.org, modofied slightly for use.
// https://processing.org/examples/animatedsprite.html

class Animation {
  PImage[] images;
  int imageCount;
  int frame;

  Animation(String imagePrefix, int count) {
    imageCount = count;
    images = new PImage[imageCount];

    for (int i = 0; i < imageCount; i++) {
      // Use nf() to number format 'i' into four digits
      String filename = imagePrefix + i + ".gif";
      images[i] = loadImage(filename);  
    }
  }

  public void display(float xpos, float ypos) {
    frame = (frame+1) % imageCount;
    image(images[frame], xpos, ypos);
    if(frame == 62)
       setState(menu);
  }

  public int getWidth() {
    return images[0].width;
  }
}
//The main menu 
class DifficultySelector extends State {

  int options;
  int selected;

  PImage image;
  PFont font;
  
  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    selected = (difficulty > 0) ? difficulty: 2;
    image = loadImage("main.png");
    font = createFont("Arial Black", 40);
  }
  
  //Gets called inside the main draw. Updates and draws everything on screen /////////////////////////////////////////////////////////
  public void draw() {

    background(0xff545454);
    image(image, 0, 0);

    if (keys[W] && keysReleased[W]) {
      selected --;
      if (selected == 0)
        selected = 3;
      keysReleased[W] = false;
    }
    if (keys[S] && keysReleased[S]) {
      selected ++;
      if (selected == 4)
        selected = 1;
      keysReleased[S] = false;
    }

    if (keys[ENTR]) {
      difficulty = selected;

      if (difficulty == 1)
        lives = 5; 
      else if (difficulty == 2)
        lives = 3; 
      else 
        lives = 1;
      setState(tutorial);
    }
    
    textFont(font);

    fill(selected == 1 ? 0xff35c762 : 0xffFFFFFF);
    text("NOOB", 335, 400);
    fill(selected == 2 ? 0xff35c762 : 0xffFFFFFF);
    text("NORMAL", 310, 500);
    fill(selected == 3 ? 0xff35c762 : 0xffFFFFFF);
    text("HARDCORE", 285, 600);
  }
}
//Entity class

//All entities (player and walker) are based off this
class Entity {

  float x; //x coordinate
  float y; //y coordiante
  float speed; //how fast it travels
  Level level; //what level the entity is in
  boolean isDead = false; //wether the entity is alive or dead
  float gravity = 0; //the current force of gravity

  //Constructor. X: x-coordinate of entity. Y: y-coordinate. speed: how fast it can go. Level: What level its currently on //////////////////////////////////
  Entity(float x, float y, float speed, Level level) {
    this.x = x; 
    this.y = y; 
    this.speed = speed;

    this.level = level;
  }

  //checks if 2 entities are colliding and runs the proper collided method////////////////////////////////////////////////////////////////////////////////
  public void collidingWith(Entity c) {
    if (abs(x - c.x) < 30 && abs(y - c.y) < 30) {
      c.collided(this, this.level);
    }
  }

  //runs after 2 entities collide. e: what entity collided with it. l: level where colloision occured ///////////////////////////////////////////////////////
  public void collided(Entity e, Level l) {
  }

  //boolean method that checks if the entity is currently on a block or is in the air. Returns true if player is standing on a block/////////////////////////////
  public boolean onBlock() {
    try {
      if (level.tileMap[(int)x/50][(int)(y + 31 - gravity)/50] == 1 || level.tileMap[(int)(x + 30)/50][(int)(y + 31- gravity)/50] == 1) {
        if (((int)y/50) * 50 - (y + 30) < abs(gravity)) {
          if (gravity < -3) {          
            gravity = ((int)y/50) * 50 - (y + 30);
          }
        }
      }
      if (level.tileMap[(int)x/50][(int)(y + 30)/50] == 1 || level.tileMap[(int)(x + 30)/50][(int)(y + 30)/50] == 1) {
        return true;
      }
    }
    catch(IndexOutOfBoundsException e) {
    }
    return false;
  }


  //updates y position based on gravity each tick //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void updateGravity() {
    try {
      if (!onBlock())
        gravity += 0.2f;
      else 
        gravity = 0;

      y += gravity;

      if (onBlock())
        if ((y+30) % 50 == 0);
        else if ((y + 30) % 50 < 25)
          y = y - ((y+30) % 50);
        else
          y = y + (50 - (y + 30) % 50);
    }

    catch (IndexOutOfBoundsException e) {
    }
  }

  ////Gets called inside the level draw. Updates and draws everything on screen /////////////////////////////////////////////////////////////////////////////////////
  public void draw() {
    updateGravity();
  }
}
//The main menu 
class GameOver extends State {

  int options;
  int selected = 1;

  int level;
  PImage image;
  PFont font;
  PFont font1;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    selected = 1;
    image = loadImage("over.jpg");
    font = createFont("Arial Black", 40);
    font1 =  createFont("Arial Black", 36);
    finalTime = (millis() - startingTime) / 1000;
  }
  
 //Gets called inside the main draw. Updates and draws everything on screen ////////////////////////////////////////////////
  public void draw() {

    background(0xff545454);
    image(image, 0, 0);
    
    //Handles selection
    if (keys[W] && keysReleased[W]) {
      selected --;
      if (selected == 0)
        selected = 2;
      keysReleased[W] = false;
    }
    if (keys[S] && keysReleased[S]) {
      selected ++;
      if (selected == 3)
        selected = 1;
      keysReleased[S] = false;
    }

    if (keyCode == ENTER) {
      if (selected == 1) {
        reset();
        setState(diff);
      } else 
        exit();
    }
  
    //Draws everything on screen 
    fill(255);
    textFont(font1);
    text("Level: " + finalLevel, 330, 610);
    if(!isCheater)
    text("Time: " + round(finalTime * 10) / 10.0f + "s", 300 - ((int)finalTime / 100) * 15, 670);
    else{
      fill(0xffD82400);
       text("CHEATER",315,670);
    }
    fill(255);
    if (difficulty == 1)
      text("NOOB", 347, 730);
    else if (difficulty == 2)
      text("REGULAR", 315, 730);
    else 
      text("HARDCORE", 300, 730);

    textFont(font);

    fill(selected == 1 ? 0xff35c762 : 0xffFFFFFF);
    text("PLAY AGAIN", 270, 400);
    fill(selected == 2 ? 0xff35c762 : 0xffFFFFFF);
    text("EXIT", 360, 500);
  }
}
//The level class. All levels in the game inherit this class

class Level extends State {

  ArrayList<Entity> entityList = new ArrayList<Entity>(); //array list containing all living entities
  int[][] tileMap = new int[16][16]; //contains the tile map for the level
  Player player = new Player(10, 700, 2.5f, this);

  float startTime;
  float endTime;
  float currentTime;
  int level;
  PFont font1;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    entityList.removeAll(entityList);
    entityList.add(player);

    startTime = millis();

    font1 = createFont("Arial", 36);

    textFont(font1);

    startPosition();

    tileMap[15][15] = -1;
    
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    player.x = 10;
    player.y = 700;
  }

  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    startPosition();
    startTime = millis();
    initialize();

    /*for (int i = entityList.size () - 1; i >= 0; i--) {
      Entity current = entityList.get(i);
      if(current instanceof Walker){
        Walker w = (Walker)current;
        w.resetPosition();
      } 
    }*/
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    background(21);

    currentTime = endTime - ((millis() - startTime) / 1000);

    fill(21);
    rect(0, 800, 800, 51);
    if (currentTime <= 5)
      fill(0xffD82400);
    else
      fill(0xff35c762);
    rect(0, 800, 800, 8);
    fill(0);
    rect(0, 798, 800, 4);

    fill(255);
    textSize(30);

    if (currentTime <= 5)
      fill(0xffD82400);

    text("Time: " + round(currentTime * 10) / 10.0f + " s", 320, 840);

    fill(255);

    text("Lives: " + lives, 680, 840);

    text("Level: " + level, 20, 840);


    if (currentTime <= 0) {
      this.player.isDead = true;
      startTime = millis();
    }

    //draws map by reading tilemap
    for (int y = 0; y < 16; y++) {
      for (int x = 0; x < 16; x++) {
        if (tileMap[x][y] == 1) {
          fill(255);
          rect(x * 50, y* 50, 50, 50);
        } else if (tileMap[x][y] == 2) {
          fill(0xffFF7D03);
          rect(x * 50, y* 50, 50, 50);
        } else if (tileMap[x][y] == -1) {
          fill(0xff1DD1E0);
          rect(x * 50, y* 50, 50, 50);
        } else if (tileMap[x][y] == 3) {
          fill(0xffD125E5);
          rect(x * 50, y* 50, 50, 50);
        }
      }
    }

    //draws all entities to screen
    for (int i = entityList.size () - 1; i >= 0; i--) {
      Entity current = entityList.get(i);
      current.draw();
    }

    //checks for entity collisions and calls proper collision method
    for (int i = 0; i < entityList.size (); i++) {
      Entity entity = entityList.get(i);
      for (int a = 0; a < entityList.size (); a++) {
        if (a != i) {
          Entity entity1 = entityList.get(a);
          entity.collidingWith(entity1);
        }
      }
    }
  }
}
class LevelEight extends Level {

  boolean powerUp = false;
  PImage jump;
  PImage tileKey;
  PImage box;
  PImage tileKey1;
  PImage box1;
  float boxY = 50;
  float boxY1 = 50;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();
    this.tileMap = lvl8TM;

    jump = loadImage("jump.png");
    tileKey = loadImage("key1.png");
    box = loadImage("box1.png");
    tileKey1 = loadImage("key2.png");
    box1 = loadImage("box2.png");

    boxY = 50;
    boxY1 = 50;

    powerUp = false;
    player.jumpMultiplier = 1;

    if (difficulty == 1)
      endTime = 60;
    else if (difficulty == 2)
      endTime = 50;
    else 
      endTime = 40;

    tileMap[14][13] = 1;
    tileMap[6][12] = 1;

    level = 8;

    entityList.add(new Walker(620, 2.7f, 1, 360, 515, this));
    entityList.add(new Walker(270, 2.1f, 1, 10, 265, this));
    entityList.add(new Walker(120, 1.6f, 1, 550, 720, this));
    entityList.add(new Walker(120, 1.6f, 1, 550, 720, this, 550 + 80));
  }

  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    powerUp = false; 
    player.jumpMultiplier = 1;

    tileMap[6][12] = 1;
  }


  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {
    super.draw();

    fill(255);
    rect(300, 600, 50, boxY);
    rect(700, 650, 50, boxY1);

    if (tileMap[14][13] == 1) {
      image(tileKey1, 754, 40);
      image(box1, 710, 660);
    } else if (tileMap[14][13] != 1 && boxY1 > 0) {
      boxY1-= 1;
    }

    if (tileMap[6][12] == 1) {
      image(tileKey, 263, 415);
      image(box, 310, 610);
    } else if (tileMap[6][12] != 1 && boxY > 0) {
      boxY-= 1;
    }

    //20, 270
    if (!powerUp)
      image(jump, 660, 210);

    if (player.x >= 631 && player.x <= 690 && player.y <=230 && player.y >= 185 && !powerUp) {
      player.jumpMultiplier = 1.3f;
      powerUp = true;
    }

    if (player.x >= 263 - 30 && player.x <= 283 && player.y <= 430 && player.y >= 370) {
      tileMap[6][12] = 0;
    }

    if (player.x >= 725 && player.x <= 800 && player.y <= 70 && player.y>= 8) {
      tileMap[14][13] = 0;
    }

    if (player.y > 805 - 30) {
      setState(lvl9);
    }
  }
}
//Level Four
class LevelFive extends Level {

  boolean powerUp = false;
  PImage jump;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    jump = loadImage("jump.png");

    if (difficulty == 1)
      endTime = 36;
    else if (difficulty == 2)
      endTime = 29;
    else 
      endTime = 23;

    level = 5;
    
    player.jumpMultiplier = 1;

    powerUp = false;

    entityList.add(new Walker(300 - 30, 2.0f, 1, 60, 280 - 30, this));
    entityList.add(new Walker(150 - 30, 2.0f, 2, 390 - 30, 155, this)); 
    entityList.add(new Walker(750-30, 1.5f, 1, 470, 740 - 30, this));

    this.tileMap = lvl5TM;
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    player.x = 20;
    player.y = 8 * 50;
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    powerUp = false; 
    player.jumpMultiplier = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {
    super.draw();

    textFont(font1);
    fill(255);
    text("Take the x2 for double jump!", 200, 31);

    //20, 270
    if (!powerUp)
      image(jump, 20, 270);

    if (player.x <= 20 + 20 && player.y <= 270 + 2 && !powerUp) {
      player.jumpMultiplier = 1.3f;
      powerUp = true;
    }

    if (player.y > 805 - 30) {
      setState(lvl6);
    }
  }
}
//Level Four

class LevelFour extends Level {

  boolean powerUp = false;
  PImage jump;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    if (difficulty == 1)
      endTime = 35;
    else if (difficulty == 2)
      endTime = 28;
    else 
      endTime = 22;

    level = 4;
    
    player.jumpMultiplier = 1;

    entityList.add(new Walker(720, 3.0f, 2, 260, 5, this));
    entityList.add(new Walker(370, 2.0f, 1, 160, 260, this)); 

    boolean powerUp = false;
    
    this.tileMap = lvl4TM;
  }

  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    powerUp = false; 
    player.jumpMultiplier = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    super.draw();

    if (player.y > 805 - 30) {
      setState(lvl5);
    }
  }
}
class LevelNine extends Level {

  boolean powerUp = false;
  PImage jump;
  PImage tileKey;
  PImage box;
  float boxY = 50;

  PImage tileKey1;
  PImage box1;
  float boxY1 = 50;

  int count = 0;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    boxY = 50; 
    boxY1 = 50;
    
    powerUp = false;
    player.jumpMultiplier = 1;

    this.tileMap = lvl9TM;
    tileMap[0][10] = 1;
    tileMap[1][10] = 1;

    tileMap[14][14] = 1;

    jump = loadImage("jump.png");
    tileKey = loadImage("key1.png");
    box = loadImage("box1.png");

    tileKey1 = loadImage("key2.png");
    box1 = loadImage("box2.png");

    if (difficulty == 1)
      endTime = 60;
    else if (difficulty == 2)
      endTime = 50;
    else 
      endTime = 40;

    level = 9;

    entityList.add(new Walker(270, 2.0f, 1, 103, 459, this));
    entityList.add(new Walker(270, 2.0f, 1, 103, 459, this, 103 + 100));
    entityList.add(new Walker(270, 2.0f, 1, 103, 459, this, 103 + 200));
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    powerUp = false; 
    count = 1;
    player.jumpMultiplier = 1;

    tileMap[1][10] = 1;
    tileMap[14][14] = 1;
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    super.startPosition();
    count = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    background(21);

    count+=1;

    if (count < 30) {
      tileMap[11][12] = 2;
      tileMap[13][12] = 2;
      tileMap[12][12] = 0;
    } else if (count < 60) {
      tileMap[12][12] = 0; 
      tileMap[11][12] = 0;
      tileMap[13][12] = 0;
    } else if (count < 90) {
      tileMap[12][12] = 2; 
      tileMap[11][12] = 0;
      tileMap[13][12] = 0;
    } else if (count < 120) {
      tileMap[12][12] = 0; 
      tileMap[11][12] = 0;
      tileMap[13][12] = 0;
    }

    if (count == 120)
      count = 0;
    super.draw();

    fill(255);
    rect(50, 500, 50, boxY);
    rect(700, 700, 50, boxY1);

    if (tileMap[1][10] == 1) {
      image(tileKey, 660, 615);
      image(box, 60, 510);
    } else if (tileMap[1][10] != 1 && boxY > 0) {
      boxY-= 1;
    }

    if (tileMap[14][14] == 1) {
      image(tileKey1, 761, 114);
      image(box1, 710, 710);
    } else if (tileMap[14][14] != 1 && boxY1 > 0) {
      boxY1-= 1;
    }

    //20, 270
    if (!powerUp)
      image(jump, 770, 425);

    if (player.x >= 740 && player.y <= 445 && player.y >= 390 && !powerUp) {
      player.jumpMultiplier = 1.3f;
      powerUp = true;
    }

    if (player.x >= 625 && player.x <= 690 && player.y >= 581 && player.y <= 630) {
      tileMap[1][10] = 0;
    }

    if (player.x >= 731 && player.y >= 84 && player.y <= 145) {
      tileMap[14][14] = 0;
    }

    if (player.y > 805 - 30) {
      setState(lvl10a);
    }
  }
}
//Level one

class LevelOne extends Level {

  boolean pressedW = false; 
  boolean pressedA = false; 
  boolean pressedD = false;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {

    startingTime = millis();

    if (difficulty == 1)
      endTime = 20;
    else if (difficulty == 2)
      endTime = 15;
    else 
      endTime = 10;

    boolean pressedW = false; 
    boolean pressedA = false; 
    boolean pressedD = false;
    
    super.initialize();

    this.tileMap = lvl1TM;

    level = 1;
  }


  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    textFont(font1);

    super.draw();

    if (keys[A] == true)
      pressedA = true;
    if (keys[D] == true)
      pressedD = true;
    if (keys[W] == true)
      pressedW = true;

    if (pressedA || pressedD) {
      fill(255);
      textSize(40);
      text("Get to the blue block to win", 150, 100);
    } else {
      fill(255);
      textSize(40);
      text("Use 'W', 'A' and 'D' to move", 150, 100);
    }

    if (player.y > 805 - 30)
      setState(lvl2);
  }
}
class LevelSeven extends Level {

  PImage tileKey;
  PImage box;
  float boxY = 50;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    tileKey = loadImage("key1.png");
    box = loadImage("box1.png");

    if (difficulty == 1)
      endTime = 36;
    else if (difficulty == 2)
      endTime = 31;
    else 
      endTime = 26;

    level = 7;
    
    boxY = 50;

    entityList.add(new Walker(370, 3.5f, 1, 460, 710, this));
    entityList.add(new Walker(200 + 30, 2.8f, 1, 510, 710, this)); 
    entityList.add(new Walker(570, 1.7f, 2, 260, 5, this));
    entityList.add(new Walker(570, 1.7f, 2, 260, 5, this, 260 - 80));
    entityList.add(new Walker(570, 1.7f, 2, 260, 5, this, 260 - 160));

    this.tileMap = lvl7TM;

    tileMap[2][7] = 1;

    startPosition();
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////\
  public void startPosition() {
    player.x = 765;
    player.y = 330;
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    tileMap[2][7] = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    super.draw();

    fill(255);
    rect(100, 350, 50, boxY);

    if (tileMap[2][7] == 1) {
      image(tileKey, 60, 60);
      image(box, 110, 360);
    } else if (tileMap[2][7] != 1 && boxY > 0) {
      boxY-= 1;
    }

    textFont(font1);
    fill(255);
    text("Get the key to open up the purple", 200, 31);

    if (player.x <= 90 && player.y <= 70) {
      tileMap[2][7] = 0;
    }

    if (player.y > 805 - 30) {
      setState(lvl8);
    }
  }
}
class LevelSix extends Level {

  boolean powerUp = false;
  PImage jump;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    if (difficulty == 1)
      endTime = 51;
    else if (difficulty == 2)
      endTime = 43;
    else 
      endTime = 36;

    level = 6;

    powerUp = false;
    player.jumpMultiplier = 1;

    entityList.add(new Walker(370, 3.2f, 1, 60, 320, this));
    entityList.add(new Walker(70, 1.4f, 1, 15, 610, this)); 
    entityList.add(new Walker(70, 1.4f, 1, 15, 610, this, 110)); 
    entityList.add(new Walker(70, 1.4f, 1, 15, 610, this, 205)); 
    entityList.add(new Walker(70, 1.4f, 1, 15, 610, this, 300)); 

    jump = loadImage("jump.png");

    this.tileMap = lvl6TM;
  }


  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    player.x = 663;
    player.y = 696;
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {

    super.playerDead();

    powerUp = false; 
    player.jumpMultiplier = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    super.draw();

    //20, 270
    if (!powerUp)
      image(jump, 20, 70);

    if (player.x <= 20 + 20 && player.y <= 80 + 2 && !powerUp) {
      player.jumpMultiplier = 1.3f;
      powerUp = true;
    }

    if (player.y > 805 - 30)
      setState(lvl7);
  }
}
class LevelTenA extends Level {

  boolean powerUp = false;
  PImage jump;
  PImage tileKey;
  PImage box;
  float boxY = 50;

  PImage tileKey1;
  PImage box1;
  float boxY1 = 50;

  int count = 0;
  int count1 = 0;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    boxY = 50; 
    boxY1 = 50;
    powerUp = false;

    this.tileMap = lvl10aTM;
    player.jumpMultiplier = 1;
    jump = loadImage("jump.png");
    tileKey = loadImage("key1.png");
    box = loadImage("box1.png");

    tileKey1 = loadImage("key2.png");
    box1 = loadImage("box2.png");

    if (difficulty == 1)
      endTime = 80;
    else if (difficulty == 2)
      endTime = 72;
    else 
      endTime = 65;

    level = 10;

    player.x = 10;
    player.y = 700;

    entityList.add(new Walker(470, 2.0f, 2, 565, 300, this));
    entityList.add(new Walker(70, 2.1f, 1, 400, 600, this));
    entityList.add(new Walker(70, 2.1f, 1, 400, 600, this, 400 + 100));
    
    tileMap[15][15] = 1;
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();

    powerUp = false; 
    count = 1;
    count1 = 1;
    player.jumpMultiplier = 1;
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {

    super.startPosition();
    count = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    background(21);


    count+=1;
    count1+=1;

    if (count < 30) {
      tileMap[8][14] = 2;
      tileMap[10][14] = 2;
      tileMap[9][14] = 1;

      tileMap[13][1] = 0;
      tileMap[14][1] = 2;
    } else if (count < 60) {
      tileMap[8][14] = 1; 
      tileMap[10][14] = 1;
      tileMap[9][14] = 1;

      tileMap[13][1] = 0;
      tileMap[14][1] = 0;
    } else if (count < 90) {
      tileMap[8][14] = 1; 
      tileMap[10][14] = 1;
      tileMap[9][14] = 2;

      tileMap[13][1] = 2;
      tileMap[14][1] = 0;
    } else if (count < 120) {
      tileMap[8][14] = 1; 
      tileMap[10][14] = 1;
      tileMap[9][14] = 1;

      tileMap[13][1] = 0;
      tileMap[14][1] = 0;
    }

    if (count1 < 60) {
      tileMap[12][14] = 2;
      tileMap[13][14] = 0;
    } else if (count1 < 120) {
      tileMap[12][14] = 0; 
      tileMap[13][14] = 2;
    } 

    if (count1 == 120)
      count1 = 0;

    if (count == 120)
      count = 0;

    super.draw();

    image(tileKey1, 710, 65);

    if (player.x >= 675 && player.x <=740 && player.y <=102 && player.y >= 35) {
      remainingTime = currentTime;
      setState(lvl10b);
    }


    //20, 270
    if (!powerUp)
      image(jump, 665, 717);

    if (player.x >= 632 && player.x <= 690 && player.y >= 685 && player.y <=740 && !powerUp) {
      player.jumpMultiplier = 1.3f;
      powerUp = true;
    }
  }
}
class LevelTenB extends Level {

  PImage tileKey;
  PImage box;
  float boxY = 50;

  int count = 0;
  int count1 = 0;

  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    boxY = 50; 

    this.tileMap = lvl10bTM;
    tileKey = loadImage("key1.png");
    box = loadImage("box1.png");

    endTime = remainingTime;

    level = 10;

    tileMap[10][9] = 1;
    tileMap[6][6] = 2;

    tileMap[15][15] = 1;
  }


  //runs after player death ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void playerDead() {
    super.playerDead();
    lvl10a.initialize();
    setState(lvl10a);
    count = 1;
    count1 = 1;
  }

  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    super.startPosition();
    player.x = 716;
    player.y = 70;
    count = 1;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    background(21);

    count+=1;
    count1+=1;

    if (count < 30) {
      tileMap[2][11] = 2;
      tileMap[10][11] = 2;
      tileMap[4][15] = 2;

      tileMap[3][2] = 2; 
      tileMap[4][2] = 0;
      tileMap[5][2] = 2;
    } else if (count < 60) {
      tileMap[3][2] = 0; 
      tileMap[4][2] = 0;
      tileMap[5][2] = 0;
    } else if (count < 90) {
      tileMap[2][11] = 1;
      tileMap[10][11] = 1;
      tileMap[4][15] = 1;

      tileMap[3][2] = 0; 
      tileMap[4][2] = 2;
      tileMap[5][2] = 0;
    } else if (count < 120) {
      tileMap[3][2] = 0; 
      tileMap[4][2] = 0;
      tileMap[5][2] = 0;
    }

    /* if (count1 < 60) {
     tileMap[12][14] = 2;
     tileMap[13][14] = 0;
     } else if (count1 < 120) {
     tileMap[12][14] = 0; 
     tileMap[13][14] = 2;
     } */

    super.draw();

    fill(255);
    rect(500, 450, 50, boxY);

    if (tileMap[10][9] == 1) {
      image(tileKey, 210, 715);
      image(box, 510, 460);
    } else if (tileMap[10][9] != 1 && boxY > 0) {
      boxY-= 1;
    }

    if (player.x >= 183 && player.x <=240 && player.y <=750 && player.y >= 685) {
      tileMap[10][9] = 0;
    }

    if (player.x >= 370 && player.x <=450 && player.y <=450 && player.y >= 370) {
      setState(winScreen);
    }


    if (count1 == 120)
      count1 = 0;

    if (count == 120)
      count = 0;
  }
}
//Level Three

class LevelThree extends Level {


  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    if (difficulty == 1)
      endTime = 28;
    else if (difficulty == 2)
      endTime = 22;
    else 
      endTime = 16;

    level = 3;

    entityList.add(new Walker(100 - 30, 2.0f, 1, 200, 410, this));
    entityList.add(new Walker(350-30, 2.0f, 2, 320, 100, this));
    entityList.add(new Walker(750-30, 2.0f, 1, 510, 710, this));

    this.tileMap = lvl3TM;

    player.x = 20;
    player.y = 0;
  }


  //sets player to start position //////////////////////////////////////////////////////////////////////////////////////////////////////
  public void startPosition() {
    player.x = 20;
    player.y = 0;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    super.draw();

    textFont(font1);
    fill(255);
    text("Hitting The green walkers will kill you!", 200, 31);

    if (player.y > 805 - 30) 
      setState(lvl4);
  }
}
//Level two

class LevelTwo extends Level {


  //Initializes variables. Gets called once when the state switches to this  //////////////////////////////////////////////////////////
  public void initialize() {
    super.initialize();

    if (difficulty == 1)
      endTime = 25;
    else if (difficulty == 2)
      endTime = 18;
    else 
      endTime = 14;


    level = 2;

    this.tileMap = lvl2TM;
  }

  //Gets called inside the main draw. Updates and draws everything on screen //////////////////////////////////////////////////////////
  public void draw() {

    super.draw();
    textFont(font1);
    fill(255);
    text("Touching the orange block will kill you.", 110, 100);

    if (player.y > 805 - 30)
      setState(lvl3);
  }
}
//The main menu 
class Menu extends State {

  int options;
  int selected;

  PImage image;
  PFont font;
  PFont font1;

  //Initializes variables. Gets called once when the state to this screen //////////////////////////////////////////////////////////
  public void initialize() {
    selected = 1;
    image = loadImage("main.png");
    font = createFont("Arial Black", 40);
    font1 = createFont("Arial Regular", 20);
  }

  //Gets called inside the main draw. Updates and draws everything on screen /////////////////////////////////////////////////////////
  public void draw() {

    background(0xff545454);
    image(image, 0, 0);

    if (keys[W] && keysReleased[W]) {
      selected --;
      if (selected == 0)
        selected = 2;
      keysReleased[W] = false;
    }
    if (keys[S] && keysReleased[S]) {
      selected ++;
      if (selected == 3)
        selected = 1;
      keysReleased[S] = false;
    }

    if (keyCode == ENTER) {
      if (selected == 1)
        setState(diff);
      else 
        exit();
    }
    textFont(font1);
    fill(255);
    text("Use 'w' and 's' to navigate and Enter to select", 205, 650);

    textFont(font);
    fill(selected == 1 ? 0xff35c762 : 0xffFFFFFF);
    text("PLAY", 350, 400);
    fill(selected == 2 ? 0xff35c762 : 0xffFFFFFF);
    text("EXIT", 350, 500);
  }
}
//The actual player class 
//Extends entity

class Player extends Entity {

  float leftVelocity;
  float rightVelocity;
  float maxSpeed = 3.3f;
  float jumpMultiplier = 1;

  float yVelocity;

  //Contructor. X: starting x. Y: Starting y. Speed: how fast player can move. Level: what level the entity is in /////////////////////////////
  Player(float x, float y, float speed, Level level) {
    super(x, y, speed, level);
  }

  //Gets called inside the level draw. Updates and draws everything on screen /////////////////////////////////////////////////////////
  public void draw() {

    updateGravity();

    /*if (mousePressed) {
      this.x = mouseX;
      this.y = mouseY;
    }*/

    try {
      //Top collision
      if (level.tileMap[(int) (x)/50][(int)(y - gravity)/50] == 1 || level.tileMap[(int) (x + 30)/50][(int)(y  - gravity)/50] == 1)
        gravity = -2;

      //Side collision with orange block
      if (level.tileMap[(int) (x + 30)/50][(int)(y + 35)/50] == 2 || level.tileMap[(int) (x + 30)/50][(int)(y+1)/50] == 2)
        isDead = true;
      if (level.tileMap[(int) (x /*- leftVelocity*/)/50][(int)(y + 35)/50] == 2 || level.tileMap[(int) (x /*- leftVelocity*/)/50][(int)(y +1)/50] == 2)
        isDead = true;
    }
    catch (IndexOutOfBoundsException e) {
    }

    if (isDead) {

      lives--;
      level.playerDead();

      if (lives <= 0) {
        finalLevel = level.level;
        finalTime = (millis() - startingTime)/1000.0f;
        setState(gameOver);
      }

      gravity = 0;
      isDead = false;
    }

    //Moves player
    if (keys[A] == true && canMove('A')) {
      rightVelocity = speed;
      if (onBlock() && speed <= maxSpeed)
        leftVelocity += 0.05f;
      x -= leftVelocity;
    } else if (keys[D] == true && canMove('D')) {
      leftVelocity = speed;
      if (onBlock() && speed <= maxSpeed)
        rightVelocity += 0.05f;
      x += rightVelocity;
    } else {
      rightVelocity = speed;
      leftVelocity = speed;
    }

    //draws plaer
    fill(0xffCE2C2C);
    rect(x, y, 30, 30);
  }

  //Runs after colliding with an entity. e: entity it collided with. l: what level player was on when collision occured///////////////////////
  public void collided(Entity e, Level l) {
    super.collided(e, l); 
    isDead =true;
  }

  //Updates y position based on gravity. Runs each tick /////////////////////////////////////////////////////////////////////////////////////////
  public void updateGravity() {
    try {
      y -= gravity;
      if (!onBlock()) {
        if (gravity >= -8)
          gravity -= 0.4f;
      } else if (keys[W] == true)
        gravity = 7 * jumpMultiplier;
      else 
        gravity = 0;

      if (onBlock())
        if ((y+30) % 50 == 0);
        else if ((y + 30) % 50 < 5)
          y = y - ((y+30) % 50);
        else if ((y + 30) % 50 > 45)
          y = y + (50 - (y + 30) % 50);
    }
    catch (IndexOutOfBoundsException e) {
    }
  }

  //Boolean method checks wether the player can move in a certain direction. dir: what direction player wants to move. 
  //D is right and A is left. Returns true if player is allowed to move /////////////////////////////////////////////////////////////////////////////
  public boolean canMove(char dir) {
    if (dir == 'D') {
      try {
        if (x >= 800 - 30)
          return false;
        if (level.tileMap[(int) (x + 30.2f + rightVelocity)/50][(int)(y)/50] == 1 || level.tileMap[(int) (x + 30.2f + rightVelocity)/50][(int)(y + 29)/50] == 1) 
          return false;
      }
      catch (IndexOutOfBoundsException e) {
      }
    } else if (dir == 'A') {
      try {
        if (x <= 0)
          return false;
        //return (level.tileMap[(int) (x)/50][(int)((y)/50)] != 1 && level.tileMap[(int) (x - leftVelocity)/50][(int)((y + 29)/50)] != 1);
        if (level.tileMap[(int) (x - leftVelocity - 0.2f)/50][(int)((y)/50)] == 1 || level.tileMap[(int) (x - leftVelocity - 0.2f)/50][(int)((y + 29)/50)] == 1)
          return false;
      }
      catch (IndexOutOfBoundsException e) {
      }
    }
    return true;
  }
}
//Splash screen at beggining

class SplashScreen extends State {

  PImage photo;

  Animation animation1;
  
  //Gets called inside the main draw. Updates and draws splashcreen on screen /////////////////////////////////////////////////////////
  public void draw()
  {
    delay(25); 
    animation1.display(0, 0);
  }

  //Gets called once. Initializes the splashcreen animation //////////////////////////////////////////////////////////////////////
  public void initialize() {
    animation1 = new Animation("tmp-", 63);
  }
}
//Abstract state class. All states (menu's, levels, etc.) inherit this class

abstract class State {
  
  //Gets called inside the main draw. Updates and draws everything on screen /////////////////////////////////////////////////////////
  public void draw() {}
  
  //Runs once each time the state is called. Initializes all variables ///////////////////////////////////////////////////////////////
  public void initialize() {}
}
//Tile map file. 
//Contains tile maps for all the levels.

int [][] lvl1TM =  {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1},
{0,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1},
{0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1},
{0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,1},
{0,0,0,0,0,0,0,1,0,0,0,0,1,1,1,1},
{0,0,0,0,0,0,0,1,0,0,1,0,0,0,1,1},
{0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1},
{0,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1},
{0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1},
{0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1},
{0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,-1},
};
int [][] lvl2TM =  {{0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1},
{0,0,0,0,0,0,0,1,0,0,1,0,0,1,1,1},
{0,0,0,0,0,0,0,1,0,0,0,0,0,0,2,1},
{0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,1},
{0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,1},
{0,0,0,0,0,0,0,2,0,0,1,0,0,0,0,1},
{0,0,0,0,0,0,1,1,0,0,0,1,0,2,0,1},
{0,0,0,0,0,0,0,2,0,0,0,0,1,2,0,1},
{0,0,0,0,0,0,0,2,0,0,0,0,1,0,0,1},
{0,0,0,0,0,0,1,1,1,0,0,0,0,0,1,1},
{0,0,0,0,0,0,0,0,2,0,0,0,0,1,0,1},
{0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1},
{0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,1},
{0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,-1},
};

int [][] lvl3TM =  {{0,0,0,1,0,0,0,0,0,0,2,1,0,0,0,1},
{0,0,0,1,0,0,0,0,0,0,0,2,0,0,0,1},
{0,0,0,1,0,0,0,1,0,0,1,1,0,0,0,2},
{0,0,0,2,0,0,0,1,0,0,1,0,0,0,1,1},
{0,0,1,1,0,0,0,1,0,0,1,0,0,0,0,2},
{0,0,1,1,0,2,0,1,1,0,1,0,2,0,1,1},
{0,0,1,1,0,0,0,1,0,0,0,0,1,0,0,2},
{0,0,1,1,0,0,1,0,0,1,2,0,0,1,0,1},
{0,0,1,1,0,0,1,0,0,1,0,0,1,0,1,1},
{0,0,0,2,0,0,1,0,0,0,0,1,2,1,1,1},
{0,0,0,1,0,0,1,1,0,0,1,0,0,0,0,1},
{0,0,1,1,0,0,0,2,0,0,1,0,2,0,0,1},
{0,0,0,2,0,0,1,1,0,0,0,0,2,0,0,1},
{0,0,0,2,0,0,2,1,0,0,0,0,0,0,0,1},
{0,0,0,0,0,1,1,1,0,0,0,0,2,0,0,1},
{0,0,0,0,0,1,0,0,0,0,0,0,2,0,0,-1},
};

int [][] lvl4TM =  {{2,0,1,0,0,1,1,1,1,0,1,0,1,0,0,1},
{0,0,1,0,0,0,1,1,1,0,0,0,0,1,0,1},
{0,0,0,0,0,0,0,1,1,0,0,1,0,0,0,1},
{0,1,0,0,1,0,0,0,1,0,0,2,0,1,0,1},
{0,1,1,0,1,0,0,0,1,0,0,1,0,1,0,1},
{0,0,0,0,1,0,0,0,1,0,0,2,0,0,0,1},
{0,2,0,0,1,0,0,0,0,0,0,1,0,0,1,1},
{0,1,0,0,2,0,0,0,0,1,0,1,0,0,0,2},
{0,1,0,0,1,0,0,0,0,2,0,1,0,0,0,2},
{0,1,0,0,0,0,0,0,0,1,0,1,0,0,1,2},
{0,2,0,0,0,0,0,0,0,1,0,0,0,1,0,2},
{0,1,0,0,1,0,0,0,0,0,0,1,1,1,1,1},
{0,2,0,0,1,0,0,0,0,0,1,1,2,2,2,1},
{0,1,0,0,1,0,0,0,0,1,2,2,2,0,0,1},
{0,0,1,0,0,0,1,0,2,2,2,0,0,0,0,1},
{0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,-1},
};

int [][] lvl5TM =  {{0,0,0,0,1,0,1,0,0,1,0,0,0,1,0,1},
{0,0,0,0,0,0,1,0,0,1,0,2,0,1,0,1},
{0,0,0,0,1,0,1,0,0,0,2,0,0,1,0,1},
{0,2,0,1,0,0,1,0,0,1,0,0,0,0,2,1},
{0,0,0,1,0,0,1,0,0,0,2,0,0,1,0,1},
{0,0,0,1,0,0,1,0,0,0,0,2,2,0,0,1},
{0,0,0,2,0,0,2,0,0,0,0,2,0,1,0,1},
{0,0,0,1,0,0,1,0,1,0,1,0,0,0,0,2},
{0,0,0,2,0,0,1,0,0,0,0,2,0,0,0,2},
{0,0,0,0,2,0,0,1,0,0,1,0,1,0,0,1},
{0,0,0,1,0,0,0,0,0,1,1,0,1,0,0,1},
{0,0,0,1,2,0,0,0,1,1,0,0,0,0,0,1},
{0,2,0,0,0,0,2,0,2,0,0,0,0,2,0,1},
{0,0,1,1,0,1,0,0,2,0,0,0,1,0,0,1},
{0,0,0,0,0,1,0,0,2,0,0,0,2,0,0,1},
{0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,-1},
};

int [][] lvl6TM =  {{0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,1},
{0,0,1,0,0,0,0,0,1,0,0,0,0,1,0,1},
{0,0,1,0,0,0,1,0,1,0,0,0,0,0,1,1},
{0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1},
{0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,1},
{0,0,1,0,0,0,0,0,1,0,0,1,0,0,0,1},
{0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,2},
{0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,2},
{0,0,1,0,0,0,1,0,0,1,1,1,0,1,0,2},
{0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,2},
{0,0,1,0,0,0,2,0,0,2,2,1,0,1,0,1},
{0,0,1,0,0,1,2,0,0,0,0,0,0,0,1,1},
{0,0,1,0,0,2,2,0,0,0,0,0,0,0,0,1},
{0,0,0,0,1,2,2,0,0,0,0,0,0,0,0,1},
{0,0,0,0,2,2,2,0,0,0,0,0,1,1,1,1},
{0,0,0,1,2,2,2,0,0,0,0,0,0,0,0,-1},
};

int [][] lvl7TM =  {{1,1,1,1,0,0,1,0,0,0,1,0,1,0,0,1},
{2,0,1,1,0,0,1,0,1,0,1,0,1,0,0,1},
{0,0,0,1,0,0,0,1,1,0,0,0,1,0,0,1},
{0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,1},
{0,0,1,0,0,1,0,0,1,0,1,0,1,0,0,1},
{0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,1},
{0,1,0,0,0,2,0,0,2,0,0,0,0,1,0,1},
{0,1,0,0,1,1,0,0,0,2,0,0,0,1,0,1},
{0,0,1,0,0,1,1,0,1,0,0,0,0,0,2,1},
{0,0,0,0,0,2,0,0,1,0,0,0,0,0,2,1},
{0,0,0,0,0,1,1,0,1,0,0,0,0,1,0,1},
{0,0,0,1,0,1,0,0,1,0,0,0,0,0,2,1},
{0,0,0,0,0,1,1,0,1,0,0,0,0,0,2,1},
{0,0,0,1,0,1,0,0,1,0,0,0,0,1,0,1},
{0,0,0,0,0,1,1,0,1,0,0,0,0,2,2,1},
{0,0,0,0,1,1,0,0,1,0,0,0,0,0,0,-1},
};

int [][] lvl8TM =  {{0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,1},
{0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,1},
{0,0,0,0,1,0,1,0,0,1,0,1,0,1,1,1},
{0,2,0,1,0,0,1,0,0,2,0,0,0,2,0,1},
{0,1,0,1,0,0,1,0,0,1,0,0,0,0,2,1},
{0,0,0,1,0,0,1,2,0,1,0,0,0,1,0,1},
{0,0,0,2,0,0,0,1,1,1,1,1,0,1,1,1},
{0,0,0,2,0,0,0,0,1,0,0,0,0,1,2,1},
{0,0,0,1,1,1,1,0,1,0,1,1,0,1,2,1},
{0,0,0,0,2,0,0,0,0,0,0,0,0,1,2,1},
{0,0,0,0,0,0,0,1,0,1,0,1,0,1,2,1},
{0,0,0,1,0,1,0,1,0,1,0,0,0,0,2,1},
{0,0,0,1,0,0,0,1,0,1,1,0,1,0,2,1},
{0,0,0,1,0,0,1,0,0,0,1,0,0,1,1,1},
{0,0,0,2,1,0,1,1,1,0,0,0,0,0,0,1},
{0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,-1},
};

int [][] lvl9TM =  {{0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1},
{0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,1},
{0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,1},
{0,0,0,1,0,0,1,0,0,1,0,1,0,1,1,1},
{0,0,0,0,0,0,1,0,0,1,0,0,0,0,2,1},
{0,0,0,1,0,0,1,0,0,2,0,0,1,0,0,1},
{0,0,0,0,0,0,1,0,1,0,0,0,0,2,0,1},
{0,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1},
{0,0,0,0,0,0,1,0,0,2,0,0,0,0,1,1},
{0,0,1,0,0,0,1,0,0,0,2,0,1,0,0,1},
{0,0,1,0,0,0,2,0,0,1,0,0,0,0,0,1},
{0,1,0,0,0,1,0,0,0,0,2,0,0,1,0,1},
{0,1,0,0,0,0,0,1,0,1,0,0,0,1,0,1},
{0,1,2,2,0,0,0,0,0,0,0,0,0,1,0,1},
{0,0,0,0,2,0,0,0,0,1,1,1,1,1,0,1},
{0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,-1},
};

int [][] lvl10aTM =  {{2,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1},
{2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{2,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1},
{1,0,1,2,2,2,2,2,2,2,2,2,2,1,1,1},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,1},
{1,1,1,0,1,1,0,1,1,1,0,0,0,0,1,1},
{0,1,0,2,2,0,2,0,1,0,1,0,0,0,0,2},
{0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,2},
{0,0,1,0,0,0,2,0,1,0,1,0,0,0,1,1},
{0,0,1,0,0,0,1,0,1,0,1,0,1,0,1,1},
{0,0,1,0,0,0,0,0,1,0,1,0,0,0,1,1},
{0,0,1,0,0,0,0,0,2,0,1,0,0,1,1,1},
{0,0,1,0,1,0,0,0,0,0,0,1,0,0,0,1},
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1},
{0,0,1,0,0,0,1,0,0,0,0,0,0,1,1,1},
{1,1,1,1,0,0,0,1,0,1,0,0,0,1,1,1},
};

int [][] lvl10bTM =  {{1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1},
{1,0,0,0,0,0,0,0,1,0,1,0,1,0,1,1},
{1,0,1,1,1,0,0,0,0,0,0,1,0,0,1,1},
{1,0,0,1,0,0,1,0,1,0,0,0,1,1,1,1},
{1,0,0,1,0,0,0,0,0,0,1,0,1,0,0,1},
{1,0,0,1,0,0,1,0,0,1,1,0,1,0,1,1},
{1,0,0,0,0,0,1,1,1,1,1,0,0,0,1,1},
{1,0,1,0,0,0,1,0,0,0,1,0,0,1,1,1},
{1,0,1,0,0,0,1,0,-1,0,1,0,1,1,1,1},
{1,0,0,1,1,0,1,0,0,0,1,0,0,0,0,1},
{1,0,0,0,1,0,1,1,1,0,0,1,1,0,0,1},
{1,0,0,0,1,0,1,0,0,0,0,0,1,0,0,1},
{1,0,0,0,1,0,1,1,1,1,1,0,1,1,0,1},
{1,0,1,0,1,0,1,0,0,0,0,0,0,1,0,1},
{1,0,1,0,0,0,0,0,0,0,1,0,0,1,0,1},
{1,1,1,0,1,0,1,0,0,0,1,0,0,1,0,1},
};
class Tutorial extends State {

  PImage image;
  
  //Gets called once. Initializes intructions image////////////////////////////////////////////////////////////////////////////////
  public void initialize() {
    image = loadImage("instr.png");
  }
  
  //Gets called inside the main draw. Updates and draws everything on screen /////////////////////////////////////////////////////////
  public void draw() {

    image(image, 0, 0);

    if (keys[W]) {
      setState(lvl1);
    }
  }
}

//Walker class
//Extends entity

class Walker extends Entity {

  int startDir; 
  int dir;
  int start;
  int end;
  int fakeStart;

  //Constructor. y: y coordinate of walker (does not change). speed: how fast walker moves,
  //dir: which direciton walker moves, start: where it starts, 
  // end: where it ends or goes to before returning to start, level: what level walker is in//////////////////////////////////////////////
  Walker(float y, float speed, int dir, int start, int end, Level level) {

    super(start, y, speed, level);

    this.x = start;
    this.startDir = dir;
    this.dir = dir;
    this.start = start; 
    this.end = end;
    this.fakeStart = start;
  }

  //Constructor. Used when walkers start isn't equal to where it moves up to
  // y: y coordinate of walker (does not change). speed: how fast walker moves,
  //dir: which direciton walker moves, start: where it moves to, end: where it ends or goes to before returning to start
  //level: what level walker is in, fakeStart: where the walker starts at ///////////////////////////////////////////////////////////////////
  Walker(float y, float speed, int dir, int start, int end, Level level, int fakeStart) {
    super(start, y, speed, level);
    this.x = fakeStart;
    this.startDir = dir;
    this.dir = dir;
    this.start = start; 
    this.end = end;
    this.fakeStart = fakeStart;
  }

  //Booleans to check if walker is on block will return true everytime, the Y value of walker doesnt need to change ////////////////////////////////////
  public boolean onBlock() {
    return true;
  }

  //Rests x value of walker to the original starting point /////////////////////////////////////////////////////////////////////////////////////////////
  public void resetPosition() {
    this.x = fakeStart;
  }
  
  ////Gets called inside the level draw. Updates and draws everything on screen /////////////////////////////////////////////////////////////////////////////////////
  public void draw() {
    super.draw();

    if (dir == 2)
      x-= speed;
    else if (dir == 1)  
      x+= speed;

    if (startDir == 1) {
      if (dir == 1 && x >= (end + speed)) 
        switchDir();

      if (dir == 2 && x <= (start + speed) ) 
        switchDir();
    } else {
      if (dir == 1 && x >= (start + speed)) 
        switchDir();

      if (dir == 2 && x <= (end + speed) ) 
        switchDir();
    }

    fill(0xff6ED818);
    rect(x, y, 30, 30);
  }
  
  //stwitches direction walker is moving at //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  public void switchDir() {
    dir = (dir == 1) ? 2 : 1;
  }
}
//The main menu 
class WinScreen extends State {

  int options;
  int selected;

  int level;
  PImage image;
  PFont font;
  PFont font1;

  //Initializes variables. Gets called once when the state to this screen ///////////////////////////////////////////////
  public void initialize() {
    selected = 1;
    image = loadImage("src/win.png");
    font = createFont("Arial Black", 40);
    font1 =  createFont("Arial Black", 36);
    finalTime = (millis() - startingTime) / 1000;
  }
  
 //Gets called inside the main draw. Updates and draws everything on screen ////////////////////////////////////////////////
  public void draw() {

    background(0xff545454);
    image(image, 0, 0);
    
    //Handles selection
    if (keys[W] && keysReleased[W]) {
      selected --;
      if (selected == 0)
        selected = 2;
      keysReleased[W] = false;
    }
    if (keys[S] && keysReleased[S]) {
      selected ++;
      if (selected == 3)
        selected = 1;
      keysReleased[S] = false;
    }

    if (keyCode == ENTER) {
      if (selected == 1) {
        reset();
        setState(diff);
      } else 
        exit();
    }
  
    //Draws everything on screen 
    fill(255);
    textFont(font1);
    text("Level: " + finalLevel, 330, 610);
    if(!isCheater)
    text("Time: " + round(finalTime * 10) / 10.0f + "s", 300 - ((int)finalTime / 100) * 15, 670);
    else{
      fill(0xffD82400);
       text("CHEATER",315,670);
    }
    fill(255);
    if (difficulty == 1)
      text("NOOB", 347, 730);
    else if (difficulty == 2)
      text("REGULAR", 315, 730);
    else 
      text("HARDCORE", 294, 730);

    textFont(font);

    fill(selected == 1 ? 0xff35c762 : 0xffFFFFFF);
    text("PLAY AGAIN", 270, 410);
    fill(selected == 2 ? 0xff35c762 : 0xffFFFFFF);
    text("EXIT", 360, 500);
  }
}
  public void settings() {  size(800, 850); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "BoxLife" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
